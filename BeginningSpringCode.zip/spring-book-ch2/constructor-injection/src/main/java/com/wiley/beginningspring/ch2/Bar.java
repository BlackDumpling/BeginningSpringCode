package com.wiley.beginningspring.ch2;

public class Bar {

}
