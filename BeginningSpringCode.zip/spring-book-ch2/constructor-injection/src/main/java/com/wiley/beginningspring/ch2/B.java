package com.wiley.beginningspring.ch2;

public class B {
	private A a;

	public B(A a) {
		this.a = a;
	}
}
