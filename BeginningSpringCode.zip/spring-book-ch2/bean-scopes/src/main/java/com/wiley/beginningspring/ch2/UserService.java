package com.wiley.beginningspring.ch2;

public class UserService {
	private UserPreferences userPreferences;
	
	public void setUserPreferences(UserPreferences userPreferences) {
		this.userPreferences = userPreferences;
	}
}
