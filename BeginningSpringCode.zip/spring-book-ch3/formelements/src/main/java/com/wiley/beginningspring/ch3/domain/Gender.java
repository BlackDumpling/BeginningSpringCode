package com.wiley.beginningspring.ch3.domain;

public enum Gender {
	MALE,
	FEMALE;
}
