package com.wiley.beginningspring.ch5;
public interface BookService {
    public void save(Book book);
}
