package com.wiley.beginningspring.ch10;

/**
 * Created by mertcaliskan
 * on 21/08/14.
 */
public class Course {

    private String name;

    public Course(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
