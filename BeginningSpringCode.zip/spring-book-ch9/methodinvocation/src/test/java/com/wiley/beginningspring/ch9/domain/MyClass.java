package com.wiley.beginningspring.ch9.domain;

/**
 * Created by mertcaliskan
 * on 11/08/14.
 */
public class MyClass {
    class MyNestedClass {
        public static final int VALUE = 10;
    }
}
